"use strict";

(() => {
  const byId = (id) => document.getElementById(id);
  const form = byId("search-form");
  const searchButton = byId("search-button");
  const demoButton = byId("demo-button");
  const resultContent = byId("result-content");
  const resultsPanel = document.querySelector(".results-panel");
  let config = { live_available: false, csrf_token: "" };
  let busy = false;
  let timer = null;

  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = String(text);
    return node;
  }

  function textOrUnknown(value) {
    return typeof value === "string" && value.trim() ? value.trim() : "Not stated";
  }

  function listItems(value) {
    return Array.isArray(value) ? value.filter((item) => typeof item === "string" && item.trim()) : [];
  }

  function records(value) {
    return Array.isArray(value) ? value.filter((item) => item && typeof item === "object" && !Array.isArray(item)) : [];
  }

  function safeUrl(value) {
    if (typeof value !== "string") return null;
    try {
      const url = new URL(value);
      const host = url.hostname.toLowerCase().replace(/\.$/, "");
      if (!["https:", "http:"].includes(url.protocol) || url.username || url.password) return null;
      // Job sources should use public domain names, not local/private hosts.
      if (!host.includes(".") || /[:\[\]]/.test(host) || /^[\d.]+$/.test(host)) return null;
      if (/(^|\.)(localhost|local|internal|invalid|test)$/.test(host)) return null;
      return url.href;
    } catch (_) {
      return null;
    }
  }

  function sourceLink(url, label, className = "") {
    const checked = safeUrl(url);
    if (!checked) return null;
    const link = element("a", className, label);
    link.href = checked;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    return link;
  }

  function appendList(parent, values, ordered = false) {
    const items = listItems(values);
    if (!items.length) return;
    const list = element(ordered ? "ol" : "ul");
    for (const item of items) list.append(element("li", "", item));
    parent.append(list);
  }

  function headingWithCount(title, count) {
    const heading = element("h3", "result-section-heading", title);
    heading.append(element("span", "count-badge", count));
    return heading;
  }

  function infoField(label, value) {
    const container = element("div");
    container.append(element("span", "detail-term", label));
    container.append(element("span", "detail-value", value));
    return container;
  }

  function makeJobCard(job, demo, uncertain) {
    const article = element("article", "job-card");
    const header = element("div", "job-card-header");
    const titles = element("div");
    titles.append(element("h4", "", textOrUnknown(job.title)));
    titles.append(element("p", "employer-line", textOrUnknown(job.employer)));
    const arrangements = { in_person: "In person", remote: "Remote", hybrid: "Hybrid", any: "", not_stated: "Work arrangement not stated" };
    const arrangement = arrangements[job.work_arrangement] ?? job.work_arrangement;
    titles.append(element("p", "location-line", [textOrUnknown(job.location), arrangement].filter(Boolean).join(" · ")));
    header.append(titles);
    const label = uncertain ? "Needs confirmation" : (job.match_label || "Possible match");
    header.append(element("span", "match-badge" + (uncertain ? " uncertain" : ""), label));
    article.append(header);

    const details = element("div", "job-details");
    details.append(infoField("Pay", textOrUnknown(job.pay)));
    details.append(infoField("Schedule", textOrUnknown(job.schedule)));
    details.append(infoField("Employer’s minimum age", Number.isFinite(job.minimum_age) ? `${job.minimum_age}+` : "Needs confirmation"));
    const requirements = listItems(job.requirements);
    details.append(infoField("Requirements", requirements.length ? requirements.join("; ") : "Not stated"));
    article.append(details);

    const reasons = listItems(job.why_fit);
    if (reasons.length) {
      article.append(element("h5", "", "Why it might fit"));
      appendList(article, reasons);
    }
    const uncertainties = listItems(job.uncertainties);
    if (uncertainties.length) {
      const note = element("div", "uncertainties");
      note.append(element("h5", "", "What to check"));
      appendList(note, uncertainties);
      article.append(note);
    }

    const evidence = records(job.evidence);
    if (evidence.length) {
      const evidenceBox = element("div", "job-source-list");
      evidenceBox.append(element("h5", "", demo ? "Example supporting details" : "Supporting details"));
      for (const item of evidence) {
        const line = element("p", "source-evidence", textOrUnknown(item.claim));
        if (!demo) {
          const link = sourceLink(item.source_url, "View source ↗");
          if (link) line.append(document.createTextNode(" "), link);
          else line.append(document.createTextNode(" — Source unavailable; confirm this detail."));
        }
        evidenceBox.append(line);
      }
      article.append(evidenceBox);
    }

    const footer = element("div", "job-card-footer");
    const dates = element("div", "job-dates");
    dates.append(element("div", "", `Posted: ${textOrUnknown(job.posted_date)}`));
    dates.append(element("div", "", demo ? "Fictional example — not a current opening" : `AI checked: ${textOrUnknown(job.checked_date)}`));
    footer.append(dates);
    if (demo) {
      footer.append(element("span", "demo-link-label", "Example only · no application"));
    } else {
      const link = sourceLink(job.application_url || job.listing_url, "View original listing ↗", "apply-link");
      footer.append(link || element("span", "demo-link-label", "No valid listing link available"));
    }
    article.append(footer);
    return article;
  }

  function supportPanel(title, values, ordered = false) {
    if (!listItems(values).length) return null;
    const panel = element("section", "support-panel");
    panel.append(element("h3", "", title));
    appendList(panel, values, ordered);
    return panel;
  }

  function downloadResults(data) {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = element("a");
    link.href = url;
    const date = typeof data.search_date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(data.search_date) ? data.search_date : "results";
    link.download = `teen-job-compass-${data.mode === "demo" ? "fictional-demo-" : ""}${date}.json`;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function renderResults(data) {
    resultContent.replaceChildren();
    const demo = data.mode === "demo";
    const best = records(data.best_matches);
    const uncertain = records(data.needs_confirmation);
    const total = best.length + uncertain.length;

    if (demo) {
      const banner = element("div", "demo-banner");
      banner.append(element("strong", "", "Fictional demo results"));
      banner.append(document.createTextNode("These examples show how the app works. They are not real job openings, and no live AI search was run."));
      resultContent.append(banner);
    } else if (data.mode === "offline") {
      resultContent.append(element("p", "result-note", "Live browsing was unavailable. These are search suggestions, not verified current openings."));
    }

    const meta = element("div", "result-meta");
    meta.append(element("span", "", `${demo ? "Example generated" : data.mode === "offline" ? "Plan date" : "Search date"}: ${textOrUnknown(data.search_date)}`));
    const download = element("button", "download-button", "Download results ↓");
    download.type = "button";
    download.addEventListener("click", () => downloadResults(data));
    meta.append(download);
    resultContent.append(meta);
    if (data.summary) resultContent.append(element("p", "result-summary", data.summary));

    const assumptions = supportPanel("Search assumptions", data.assumptions);
    if (assumptions) resultContent.append(assumptions);

    if (best.length) {
      const section = element("section", "result-section");
      section.append(headingWithCount("Best matches", best.length));
      for (const job of best) section.append(makeJobCard(job, demo, false));
      resultContent.append(section);
    }

    if (uncertain.length) {
      const section = element("section", "result-section");
      section.append(headingWithCount("Needs confirmation", uncertain.length));
      section.append(element("p", "section-description", "These jobs have details to check before you know whether they fit."));
      for (const job of uncertain) section.append(makeJobCard(job, demo, true));
      resultContent.append(section);
    }

    if (!total) {
      const note = element("div", "result-note");
      note.append(element("strong", "", data.mode === "offline" ? "Your search plan is ready." : "No supported matches to show yet."));
      note.append(element("p", "", data.mode === "offline" ? "Use the phrases below to research current openings yourself. Add live search when you are ready for the AI to help check listings." : "The search did not find openings with enough evidence to include. Check the notes and search phrases below, or adjust a preference that you are comfortable changing."));
      resultContent.append(note);
    }

    const leads = records(data.leads);
    if (leads.length) {
      const panel = element("section", "support-panel");
      panel.append(element("h3", "", "Places to investigate"));
      panel.append(element("p", "section-description", "Leads only — no current opening verified."));
      for (const lead of leads) {
        const article = element("article", "lead");
        article.append(element("h4", "", textOrUnknown(lead.employer)));
        article.append(element("p", "", textOrUnknown(lead.reason)));
        const link = demo ? null : sourceLink(lead.url, "Explore this lead ↗");
        if (link) article.append(link);
        panel.append(article);
      }
      resultContent.append(panel);
    }

    const nextSteps = supportPanel("Your next steps", data.next_steps, true);
    if (nextSteps) resultContent.append(nextSteps);

    const rules = records(data.work_rules);
    if (rules.length) {
      const panel = element("section", "support-panel");
      panel.append(element("h3", "", demo ? "Example work-rule notes" : "Work rules to check"));
      for (const rule of rules) {
        const line = element("p", "work-rule", textOrUnknown(rule.summary));
        const link = demo ? null : sourceLink(rule.source_url, rule.source_title || "Official source ↗");
        if (link) line.append(document.createTextNode(" "), link);
        panel.append(line);
      }
      resultContent.append(panel);
    }

    const limitations = supportPanel("What this search could not confirm", data.limitations);
    if (limitations) resultContent.append(limitations);

    const phrases = listItems(data.search_phrases);
    if (phrases.length) {
      const panel = element("section", "support-panel");
      panel.append(element("h3", "", "Keep exploring with these searches"));
      for (const phrase of phrases) panel.append(element("div", "search-phrase", phrase));
      resultContent.append(panel);
    }

    const sources = records(data.sources);
    if (!demo && sources.length) {
      const details = element("details", "evidence-details");
      details.append(element("summary", "", "View research sources"));
      const list = element("ul");
      for (const source of sources) {
        const link = sourceLink(source.url, source.title || source.url);
        if (link) { const item = element("li"); item.append(link); list.append(item); }
      }
      details.append(list);
      resultContent.append(details);
    }

    byId("empty-state").hidden = true;
    resultContent.hidden = false;
    byId("results-count").textContent = data.mode === "offline" ? "Manual search plan" : `${total} ${demo ? "example" : "job"}${total === 1 ? "" : "s"} to explore`;
    byId("announcer").textContent = data.mode === "offline" ? "Your manual search plan is ready. No live search was performed." : `${demo ? "Fictional demo loaded." : "Search complete."} ${best.length} best matches and ${uncertain.length} results needing confirmation.`;
    resultContent.focus({ preventScroll: true });
    if (window.matchMedia("(max-width: 780px)").matches) resultsPanel.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function setBusy(value, demo = false) {
    busy = value;
    searchButton.disabled = value || !config.csrf_token;
    demoButton.disabled = value;
    resultsPanel.setAttribute("aria-busy", String(value));
    byId("loading").hidden = !value;
    if (timer) { clearInterval(timer); timer = null; }
    if (value) {
      byId("error-message").hidden = true;
      byId("empty-state").hidden = true;
      resultContent.hidden = true;
      byId("loading-title").textContent = demo ? "Opening the examples" : config.live_available ? "Looking for a good fit" : "Building your search plan";
      byId("loading-description").textContent = demo ? "Loading fictional results. No live search is being run." : config.live_available ? "Searching real listings and checking their details. This can take a few minutes." : "Organizing your preferences into searches you can reuse. No live job search is being run.";
      byId("elapsed").textContent = "0 seconds elapsed";
      const started = performance.now();
      timer = setInterval(() => {
        const seconds = Math.floor((performance.now() - started) / 1000);
        byId("elapsed").textContent = `${seconds} second${seconds === 1 ? "" : "s"} elapsed`;
      }, 1000);
      byId("results-count").textContent = demo ? "Loading examples…" : config.live_available ? "Searching…" : "Creating plan…";
    }
  }

  function showError(message) {
    byId("error-message").textContent = message;
    byId("error-message").hidden = false;
    byId("empty-state").hidden = false;
    resultContent.hidden = true;
    byId("results-count").textContent = "Ready to try again";
    byId("announcer").textContent = message;
  }

  async function readResponse(response) {
    let body;
    try { body = await response.json(); }
    catch (_) { throw new Error("The app returned an unreadable response. Check that the local server is running, then try again."); }
    if (!response.ok) {
      const message = typeof body.error === "string" ? body.error : typeof body.message === "string" ? body.message : typeof body.detail === "string" ? body.detail : "The search could not finish. Please try again.";
      throw new Error(message);
    }
    if (!body || typeof body !== "object" || Array.isArray(body)) throw new Error("The app returned an unexpected response. Please try again.");
    return body;
  }

  function collectProfile() {
    const values = new FormData(form);
    const stringValue = (name) => String(values.get(name) || "").trim();
    const numberValue = (name) => { const value = stringValue(name); return value ? Number(value) : null; };
    return {
      age: numberValue("age"), location: stringValue("location"), interests: stringValue("interests"),
      max_distance_miles: numberValue("max_distance_miles"), max_commute_minutes: numberValue("max_commute_minutes"),
      transportation: stringValue("transportation"), work_arrangement: stringValue("work_arrangement"),
      availability: stringValue("availability"), max_hours_per_week: numberValue("max_hours_per_week"),
      employment_type: stringValue("employment_type"), skills: stringValue("skills"),
      minimum_hourly_pay: numberValue("minimum_hourly_pay"), must_haves: stringValue("must_haves")
    };
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (busy || !form.reportValidity()) return;
    if (!config.csrf_token) { showError("The local app is not connected. Run app.py and open the address it prints."); return; }
    setBusy(true);
    try {
      const response = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-CSRF-Token": config.csrf_token },
        body: JSON.stringify(collectProfile()),
        credentials: "same-origin"
      });
      renderResults(await readResponse(response));
    } catch (error) {
      showError(error instanceof TypeError ? "Cannot reach the local app. Make sure app.py is still running, then try again." : error.message);
    } finally { setBusy(false); }
  });

  demoButton.addEventListener("click", async () => {
    if (busy) return;
    setBusy(true, true);
    try { renderResults(await readResponse(await fetch("/api/demo", { credentials: "same-origin" }))); }
    catch (error) { showError(error instanceof TypeError ? "Cannot load the examples. Make sure app.py is running and open the local app address." : error.message); }
    finally { setBusy(false); }
  });

  document.querySelector('a[href="#setup"]').addEventListener("click", () => { byId("setup").open = true; });

  async function initialize() {
    try {
      config = await readResponse(await fetch("/api/config", { credentials: "same-origin", cache: "no-store" }));
      config.csrf_token = typeof config.csrf_token === "string" ? config.csrf_token : "";
      config.live_available = config.live_available === true;
      searchButton.disabled = !config.csrf_token;
      searchButton.firstElementChild.textContent = config.live_available ? "Find jobs that fit me" : "Build my search plan";
      document.querySelector(".privacy-note").textContent = config.live_available ? "Live search sends these preferences to OpenAI to research job listings. Leave out contact details and other private information." : "This creates a search plan on your computer. No live AI or web search runs, and your preferences are not sent to OpenAI.";
      byId("setup-notice").hidden = config.live_available;
    } catch (_) {
      config = { live_available: false, csrf_token: "" };
      byId("setup-notice").hidden = false;
      byId("setup-notice").textContent = "Open this page through the local app: run app.py, then visit the address it prints. Live search and examples need that server.";
    }
  }

  initialize();
})();
