"""Offline regression tests for real input and HTTP boundaries. No paid calls."""

import http.client
import json
from pathlib import Path
import tempfile
import threading
import unittest

from app import Config, ProfileError, make_server, offline_plan, read_env, validate_profile
from demo import demo_results


PROFILE = {"age": 15, "location": "South Bend, Indiana", "interests": "coding and cooking"}


class ProfileTests(unittest.TestCase):
    def test_required_fields_are_requested_together(self):
        with self.assertRaises(ProfileError) as caught:
            validate_profile({})
        self.assertEqual(set(caught.exception.fields), {"age", "interests", "location"})

    def test_optional_omissions_remain_unspecified(self):
        result = validate_profile(PROFILE)
        self.assertEqual(result["transportation"], "")
        self.assertIsNone(result["max_hours_per_week"])
        self.assertIsNone(result["minimum_hourly_pay"])

    def test_age_must_be_a_whole_number_in_scope(self):
        for age in (True, False, 13, 19, 15.5, "fifteen", "nan", "inf", [], {}):
            with self.subTest(age=age), self.assertRaises(ProfileError):
                validate_profile({**PROFILE, "age": age})

    def test_numeric_limits_must_be_finite_not_boolean(self):
        for value in (True, "nan", "inf", -1, 501):
            with self.subTest(value=value), self.assertRaises(ProfileError):
                validate_profile({**PROFILE, "max_distance_miles": value})

    def test_missing_interest_and_invalid_types_are_rejected(self):
        for field, value in (("interests", "  "), ("location", []), ("skills", {}), ("availability", 3)):
            with self.subTest(field=field), self.assertRaises(ProfileError):
                validate_profile({**PROFILE, field: value})

    def test_unknown_fields_not_forwarded_to_ai(self):
        with self.assertRaises(ProfileError):
            validate_profile({**PROFILE, "api_key": "example"})

    def test_invalid_enums_rejected(self):
        for field in ("work_arrangement", "employment_type"):
            with self.subTest(field=field), self.assertRaises(ProfileError):
                validate_profile({**PROFILE, field: "anything from a webpage"})

    def test_offline_plan_never_claims_current_openings(self):
        result = offline_plan(validate_profile(PROFILE))
        self.assertEqual(result["mode"], "offline")
        self.assertIn("No live search", result["summary"])
        self.assertFalse(result["best_matches"] or result["needs_confirmation"] or result["leads"])
        self.assertEqual(len(result["search_phrases"]), 5)
        self.assertTrue(all("South Bend" in q for q in result["search_phrases"]))

    def test_demo_never_offers_application_links(self):
        result = demo_results()
        self.assertEqual(result["mode"], "demo")
        self.assertIn("fictional", result["summary"].lower())
        for job in result["best_matches"] + result["needs_confirmation"]:
            self.assertFalse(job["listing_url"] or job["application_url"])
            self.assertIn("fictional", job["employer"].lower())

    def test_env_is_parsed_without_shell_execution(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / ".env"
            path.write_text('OPENAI_API_KEY="$(not_a_command)"\nUNRECOGNIZED=value\nPORT=8002\n')
            values = read_env(path)
        self.assertEqual(values["OPENAI_API_KEY"], "$(not_a_command)")
        self.assertNotIn("UNRECOGNIZED", values)


class HttpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = make_server(Config(api_key=""), port=0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.port = cls.server.server_address[1]

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def request(self, method, path, body=None, headers=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        connection.request(method, path, body=body, headers=headers or {})
        response = connection.getresponse()
        status, response_headers, raw = response.status, dict(response.getheaders()), response.read()
        connection.close()
        return status, response_headers, raw

    def post(self, payload, **extra_headers):
        headers = {"Content-Type": "application/json", "X-CSRF-Token": self.server.app_state.csrf_token}
        headers.update(extra_headers)
        return self.request("POST", "/api/search", json.dumps(payload), headers)

    def test_config_does_not_expose_key(self):
        status, _, raw = self.request("GET", "/api/config")
        result = json.loads(raw)
        self.assertEqual(status, 200)
        self.assertEqual(set(result), {"live_available", "model", "csrf_token"})
        self.assertFalse(result["live_available"])

    def test_private_files_and_traversal_are_not_served(self):
        for path in ("/.env", "/app.py", "/../app.py", "/static/../.env", "/%2e%2e/.env"):
            with self.subTest(path=path):
                self.assertEqual(self.request("GET", path)[0], 404)

    def test_host_header_cannot_rebind_local_server(self):
        status, _, _ = self.request("GET", "/api/config", headers={"Host": "attacker.example"})
        self.assertEqual(status, 403)

    def test_cross_origin_request_is_blocked(self):
        self.assertEqual(self.post(PROFILE, Origin="https://attacker.example")[0], 403)

    def test_missing_csrf_token_is_blocked(self):
        status, _, _ = self.request("POST", "/api/search", json.dumps(PROFILE), {"Content-Type": "application/json"})
        self.assertEqual(status, 403)

    def test_nonascii_csrf_token_is_rejected_without_crashing(self):
        status, _, _ = self.post(PROFILE, **{"X-CSRF-Token": "é"})
        self.assertEqual(status, 403)

    def test_no_key_produces_honest_offline_plan(self):
        status, headers, raw = self.post(PROFILE)
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(raw)["mode"], "offline")
        self.assertEqual(headers["Cache-Control"], "no-store")

    def test_invalid_profile_never_reaches_engine(self):
        status, _, raw = self.post({**PROFILE, "age": True})
        self.assertEqual(status, 422)
        self.assertIn("error", json.loads(raw))

    def test_nonfinite_json_is_rejected(self):
        body = '{"age":15,"interests":"coding","location":"South Bend","max_hours_per_week":NaN}'
        status, _, _ = self.request("POST", "/api/search", body, {
            "Content-Type": "application/json", "X-CSRF-Token": self.server.app_state.csrf_token})
        self.assertEqual(status, 400)

    def test_demo_response_remains_separate(self):
        status, _, raw = self.request("GET", "/api/demo")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(raw)["mode"], "demo")


if __name__ == "__main__":
    unittest.main()
