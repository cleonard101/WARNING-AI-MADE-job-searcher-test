"""Offline regression tests. All employers, listings, and facts are synthetic.

No test contacts an API, opens an employer page, or claims a real vacancy.
Run with: python -m unittest discover -s tests -v
"""

from copy import deepcopy
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


TODAY = "2026-10-29"
GOV_RULE = "https://www.dol.gov/agencies/whd/youthrules"
STATE_RULE = "https://www.in.gov/dol/youth-employment/"
COMPANY_POLICY = "https://example.com/hiring-faq"
ROUTE = "https://maps.example.com/routes/synthetic-route"


def profile(**changes):
    value = {
        "age": 15, "location": "South Bend, Indiana", "interests": "Cooking",
        "max_distance_miles": None, "max_commute_minutes": None,
        "transportation": "", "work_arrangement": "any", "availability": "",
        "max_hours_per_week": None, "employment_type": "any", "skills": "",
        "minimum_hourly_pay": None, "must_haves": "",
    }
    value.update(changes)
    return value


def candidate(identifier="1", **changes):
    url = "https://example.com/jobs/" + identifier
    value = {
        "title": "Synthetic assistant", "employer": "Example Employer",
        "location": "South Bend, Indiana", "work_arrangement": "in_person",
        "pay": "$15 per hour", "pay_basis": "hourly", "pay_currency": "USD",
        "hourly_pay_min": 15, "hourly_pay_max": 15, "paid_status": "paid",
        "schedule": "Ten hours each week", "minimum_weekly_hours": 10,
        "minimum_age": 14, "minimum_age_source_url": url,
        "listing_status": "open", "listing_kind": "specific_opening",
        "listing_url": url, "application_url": url,
        "posted_date": "2026-10-20", "deadline": None,
        "why_fit": ["The synthetic duties relate to cooking."],
        "requirements": ["Synthetic minimum age of 14."], "uncertainties": [],
        "evidence": [{"claim": "Synthetic duties and age statement.", "source_url": url}],
        "checks": {name: "meets" for name in
                   ["qualifications", "schedule", "work_rules", "location", "employment_type", "must_haves"]},
        "work_rule_source_urls": [GOV_RULE, STATE_RULE], "applicable_state": "Indiana",
        "commute_source_url": None,
        "commute_minutes": None, "distance_miles": None,
        "match_strength": "strong", "scam_concern": "none",
    }
    value.update(changes)
    return value


def dossier(candidates, *, leads=None, rules=True):
    return {
        "candidates": candidates, "leads": leads or [],
        "work_rules": [
            {"summary": "Synthetic federal rule evidence for this test.", "source_url": GOV_RULE,
             "source_title": "Synthetic federal source", "scope": "federal", "jurisdiction": "United States"},
            {"summary": "Synthetic state rule evidence for this test.", "source_url": STATE_RULE,
             "source_title": "Synthetic state source", "scope": "state", "jurisdiction": "Indiana"},
        ] if rules else [],
    }


def research(candidates=(), *, extra=(), not_opened=()):
    urls = {GOV_RULE, STATE_RULE, *extra}
    for item in candidates:
        for name in ["listing_url", "minimum_age_source_url", "application_url", "commute_source_url"]:
            if url := engine.canonical_url(item.get(name)):
                urls.add(url)
    withheld = {engine.canonical_url(url) for url in not_opened}
    return engine.ResearchEvidence(
        text="Synthetic research used only by offline tests.",
        sources={url: {"url": url, "title": "Synthetic source"} for url in urls},
        opened_urls=urls - withheld, had_search=True,
    )


def research_response(evidence, *, search_completed=True):
    output = [{"type": "web_search_call", "status": "completed" if search_completed else "failed",
               "action": {"type": "search", "sources": list(evidence.sources.values())}}]
    output += [{"type": "web_search_call", "status": "completed",
                "action": {"type": "open_page", "url": url}} for url in sorted(evidence.opened_urls)]
    output.append({"type": "message", "content": [{"type": "output_text", "text": evidence.text,
                                                    "annotations": []}]})
    return {"status": "completed", "output": output}


def extraction_response(data):
    return {"status": "completed", "output": [{"type": "message", "content": [
        {"type": "output_text", "text": json.dumps(data)}]}]}


class NormalizationTests(unittest.TestCase):
    def normalize(self, items, *, user=None, evidence=None, leads=None, rules=True):
        return engine.normalize_results(dossier(items, leads=leads, rules=rules), user or profile(),
                                        evidence or research(items), TODAY)

    def test_closed_duplicate_cannot_hide_later_opened_listing(self):
        valid = candidate()
        closed = {**valid, "listing_status": "closed"}
        result = self.normalize([closed, valid])
        self.assertEqual([j["listing_url"] for j in result["best_matches"]], [valid["listing_url"]])

    def test_weaker_same_role_cannot_hide_valid_listing_or_remain_as_lead(self):
        for weakness in ["general", "unopened", "unknown"]:
            with self.subTest(weakness=weakness):
                valid, weak = candidate("valid"), candidate("weak")
                withheld = []
                if weakness == "general":
                    weak["listing_kind"] = "general_careers_page"
                elif weakness == "unopened":
                    withheld.append(weak["listing_url"])
                else:
                    weak["listing_status"] = "unknown"
                result = self.normalize([weak, valid], evidence=research([weak, valid], not_opened=withheld))
                self.assertEqual(len(result["best_matches"]), 1)
                self.assertEqual(result["best_matches"][0]["listing_url"], valid["listing_url"])
                self.assertEqual(result["leads"], [])

    def test_complete_evidence_precedes_uncertain_duplicate(self):
        weak = candidate("weak", minimum_age=None)
        valid = candidate("valid")
        result = self.normalize([weak, valid])
        self.assertEqual(len(result["best_matches"]), 1)
        self.assertEqual(result["needs_confirmation"], [])

    def test_search_snippet_is_a_lead_even_if_model_calls_it_open(self):
        item = candidate()
        result = self.normalize([item], evidence=research([item], not_opened=[item["listing_url"]]))
        self.assertEqual(result["best_matches"], [])
        self.assertEqual(result["needs_confirmation"], [])
        self.assertEqual(len(result["leads"]), 1)

    def test_government_rules_and_company_policy_do_not_establish_position_age(self):
        for source in [GOV_RULE, COMPANY_POLICY]:
            with self.subTest(source=source):
                # An unsupported policy minimum must not exclude a teen either.
                item = candidate(minimum_age=18, minimum_age_source_url=source)
                result = self.normalize([item])
                self.assertEqual(result["best_matches"], [])
                self.assertEqual(len(result["needs_confirmation"]), 1)
                self.assertIsNone(result["needs_confirmation"][0]["minimum_age"])
                self.assertEqual(result["excluded_count"], 0)

    def test_specific_government_job_listing_can_support_its_own_minimum_age(self):
        url = "https://example.gov/jobs/synthetic-role"
        item = candidate(listing_url=url, application_url=url, minimum_age_source_url=url,
                         evidence=[{"claim": "Synthetic job-specific requirement.", "source_url": url}])
        self.assertEqual(len(self.normalize([item])["best_matches"]), 1)

    def test_closed_and_expired_excluded_but_today_deadline_retained(self):
        items = [candidate("closed", title="Closed synthetic role", listing_status="closed"),
                 candidate("expired", title="Expired synthetic role", deadline="2026-10-28"),
                 candidate("today", title="Today synthetic role", deadline=TODAY)]
        result = self.normalize(items)
        self.assertEqual(result["excluded_count"], 2)
        self.assertEqual([j["title"] for j in result["best_matches"]], ["Today synthetic role"])

    def test_known_numeric_conflicts_are_excluded(self):
        cases = [
            (candidate(minimum_age=16), profile()),
            (candidate(minimum_weekly_hours=20), profile(max_hours_per_week=10)),
            (candidate(hourly_pay_min=10, hourly_pay_max=12), profile(minimum_hourly_pay=15)),
            (candidate(distance_miles=12, commute_source_url=ROUTE), profile(max_distance_miles=5)),
            (candidate(commute_minutes=30, commute_source_url=ROUTE), profile(max_commute_minutes=10)),
        ]
        for item, user in cases:
            with self.subTest(profile=user):
                result = self.normalize([item], user=user)
                self.assertEqual(result["excluded_count"], 1)
                self.assertFalse(result["best_matches"] or result["needs_confirmation"] or result["leads"])

    def test_unverified_route_is_uncertain_not_an_invented_numeric_conflict(self):
        item = candidate(commute_minutes=80, commute_source_url=ROUTE)
        result = self.normalize([item], user=profile(max_commute_minutes=10),
                                evidence=research([item], not_opened=[ROUTE]))
        self.assertEqual(result["excluded_count"], 0)
        self.assertEqual(len(result["needs_confirmation"]), 1)

    def test_open_ended_starting_pay_below_floor_needs_confirmation(self):
        item = candidate(hourly_pay_min=12, hourly_pay_max=None)
        result = self.normalize([item], user=profile(minimum_hourly_pay=15))
        self.assertEqual(result["excluded_count"], 0)
        self.assertEqual(len(result["needs_confirmation"]), 1)

    def test_missing_official_rules_prevent_confident_minor_match(self):
        result = self.normalize([candidate()], rules=False)
        self.assertEqual(result["best_matches"], [])
        self.assertEqual(len(result["needs_confirmation"]), 1)
        self.assertTrue(any("official" in text for text in result["limitations"]))

    def test_rejected_exact_vacancy_cannot_reappear_as_lead(self):
        rejected_values = [
            {"scam_concern": "clear"}, {"paid_status": "unpaid"},
            {"listing_status": "closed"}, {"minimum_age": 21},
        ]
        for values in rejected_values:
            with self.subTest(values=values):
                item = candidate(**values)
                distinct_careers_url = "https://example.com/careers"
                leads = [{"employer": "Example Employer", "url": item["listing_url"]},
                         {"employer": "Example Employer", "url": distinct_careers_url}]
                result = self.normalize([item], leads=leads,
                                        evidence=research([item], extra=[distinct_careers_url]))
                self.assertEqual(result["excluded_count"], 1)
                self.assertEqual([lead["url"] for lead in result["leads"]], [distinct_careers_url])

    def test_unknown_location_cannot_be_best_despite_meets_label(self):
        for location in ["", "Not stated", "unknown"]:
            with self.subTest(location=location):
                item = candidate(location=location)
                result = self.normalize([item])
                self.assertEqual(result["best_matches"], [])
                self.assertEqual(len(result["needs_confirmation"]), 1)
                self.assertTrue(any("worksite" in text for text in result["needs_confirmation"][0]["uncertainties"]))

    def test_unknown_title_or_employer_is_rejected(self):
        for values in [{"title": "Not stated"}, {"employer": ""}]:
            with self.subTest(values=values):
                result = self.normalize([candidate(**values)])
                self.assertEqual(result["excluded_count"], 1)
                self.assertFalse(result["best_matches"] or result["needs_confirmation"])

    def test_minors_need_distinct_federal_and_applicable_state_evidence(self):
        for missing in ["state_source", "wrong_state", "applicable_state", "distinct_sources"]:
            with self.subTest(missing=missing):
                item = candidate()
                data = dossier([item])
                if missing == "state_source":
                    data["work_rules"] = data["work_rules"][:1]
                elif missing == "wrong_state":
                    data["work_rules"][1]["jurisdiction"] = "Michigan"
                elif missing == "applicable_state":
                    item["applicable_state"] = None
                else:
                    data["work_rules"][1]["source_url"] = GOV_RULE
                result = engine.normalize_results(data, profile(), research([item]), TODAY)
                self.assertEqual(result["best_matches"], [])
                self.assertEqual(len(result["needs_confirmation"]), 1)
                self.assertTrue(any("federal and state" in text for text in result["needs_confirmation"][0]["uncertainties"]))

    def test_limits_apply_after_duplicate_leads_are_removed(self):
        valid = candidate("valid")
        weak = candidate("weak", listing_kind="general_careers_page")
        leads = [{"employer": f"Lead {i}", "url": f"https://example.com/lead/{i}"} for i in range(5)]
        result = self.normalize([weak, valid], leads=leads,
                                evidence=research([weak, valid], extra=[x["url"] for x in leads]))
        self.assertEqual(len(result["leads"]), 3)
        self.assertNotIn(weak["listing_url"], [lead["url"] for lead in result["leads"]])

    def test_shortlist_next_steps_and_search_phrase_limits(self):
        items = [candidate(str(i), title=f"Synthetic role {i}",
                           minimum_age=None if i % 2 else 14) for i in range(15)]
        result = self.normalize(items)
        self.assertEqual(len(result["best_matches"]) + len(result["needs_confirmation"]), 10)
        self.assertLessEqual(len(result["next_steps"]), 3)
        self.assertEqual(len(result["search_phrases"]), 5)

    def test_excluded_job_never_remains_in_summary_or_next_steps(self):
        rejected = candidate(title="Do not recommend this role", minimum_age=25)
        data = dossier([rejected])
        data["summary"] = "Apply for Do not recommend this role immediately."
        data["next_steps"] = [data["summary"]]
        result = engine.normalize_results(data, profile(), research([rejected]), TODAY)
        self.assertNotIn(rejected["title"], result["summary"] + " ".join(result["next_steps"]))


class SourceAndLinkTests(unittest.TestCase):
    def test_unsafe_links_are_rejected(self):
        for value in ["javascript:alert(1)", "file:///tmp/a", "https://localhost/",
                      "https://127.0.0.1/", "https://169.254.169.254/", "https://[::1]/",
                      "https://0x7f000001/", "https://0177.0.0.1/", "https://example.com:8000/",
                      "https://user:secret@example.com/", "https://example.com\\@localhost/",
                      "https://example.com/\nsecret"]:
            with self.subTest(url=value):
                self.assertIsNone(engine.canonical_url(value))

    def test_spa_vacancy_fragments_are_preserved_and_distinct(self):
        first = "https://careers.example.com/#/jobs/123"
        second = "https://careers.example.com/#/jobs/456"
        self.assertEqual(engine.canonical_url(first), first)
        self.assertEqual(engine.canonical_url(second), second)
        self.assertNotEqual(engine.canonical_url(first), engine.canonical_url(second))
        self.assertEqual(engine.canonical_url("https://example.com/jobs?id=7&utm_source=test#apply"),
                         "https://example.com/jobs?id=7#apply")

    def test_citations_find_actions_and_failed_opens_are_not_open_page_evidence(self):
        url = "https://example.com/jobs/1"
        response = {"status": "completed", "output": [
            {"type": "web_search_call", "status": "completed", "action": {"type": "search", "sources": [{"url": url}]}},
            {"type": "web_search_call", "status": "completed", "action": {"type": "find_in_page", "url": url}},
            {"type": "web_search_call", "status": "failed", "action": {"type": "open_page", "url": url}},
            {"type": "message", "content": [{"type": "output_text", "text": "I opened https://example.com/jobs/invented",
               "annotations": [{"type": "url_citation", "url": url, "title": "Synthetic listing"}]}]},
        ]}
        result = engine.collect_research(response)
        self.assertTrue(result.had_search)
        self.assertIn(url, result.sources)
        self.assertFalse(result.opened_urls)
        self.assertNotIn("https://example.com/jobs/invented", result.sources)


class FullEngineTests(unittest.TestCase):
    def test_two_stage_search_uses_prompt_tool_evidence_and_strict_extraction(self):
        item = candidate()
        evidence = research([item])
        transport = Mock(side_effect=[research_response(evidence), extraction_response(dossier([item]))])
        with patch("engine.urlopen", side_effect=AssertionError("No network allowed in tests")):
            result = engine.JobSearchEngine("fake-test-key", transport=transport).search(profile())
        self.assertEqual(len(result["best_matches"]), 1)
        self.assertEqual(transport.call_count, 2)
        request1, request2 = [call.args[0] for call in transport.call_args_list]
        self.assertEqual(request1["model"], engine.DEFAULT_MODEL)
        self.assertEqual(request1["tools"][0]["type"], "web_search")
        self.assertEqual(request1["max_tool_calls"], engine.MAX_WEB_TOOL_CALLS)
        self.assertEqual(request1["tool_choice"], "required")
        self.assertIn("AI Job Search Super Prompt", request1["instructions"])
        self.assertFalse(request1["store"])
        self.assertFalse(request2["store"])
        self.assertNotIn("tools", request2)
        self.assertTrue(request2["text"]["format"]["strict"])
        self.assertIn(item["listing_url"], json.loads(request2["input"])["opened_urls"])
        self.assertNotIn("fake-test-key", json.dumps([request1, request2]))

    def test_missing_key_makes_no_requests(self):
        transport = Mock()
        with self.assertRaises(engine.EngineError) as raised:
            engine.JobSearchEngine("", transport=transport).search(profile())
        self.assertEqual(raised.exception.status, 503)
        transport.assert_not_called()

    def test_failed_search_stops_before_extraction(self):
        transport = Mock(return_value=research_response(research([candidate()]), search_completed=False))
        with self.assertRaises(engine.EngineError):
            engine.JobSearchEngine("fake-test-key", transport=transport).search(profile())
        self.assertEqual(transport.call_count, 1)

    def test_incomplete_refused_and_invalid_outputs_fail_closed(self):
        bad_responses = [
            {"status": "incomplete", "output": []},
            {"status": "completed", "output": [{"type": "message", "content": [{"type": "refusal", "refusal": "Synthetic refusal"}]}]},
            extraction_response({"candidates": [], "leads": []}),
        ]
        for bad in bad_responses:
            with self.subTest(response=bad):
                transport = Mock(side_effect=[research_response(research([candidate()])), bad])
                with self.assertRaises(engine.EngineError):
                    engine.JobSearchEngine("fake-test-key", transport=transport).search(profile())
                self.assertEqual(transport.call_count, 2)


if __name__ == "__main__":
    unittest.main()
